"""Very small wrapper around Ollama/Mistral."""
import subprocess, json

SYSTEM_PROMPT = (
    "You are a helpful system-command assistant. "
    "Return ONLY a safe, single-line shell command that fulfils the user's request. "
    "Allowed base commands: ls, pwd, date, whoami, cat, echo. "
    "Use absolute or relative paths; no pipes or &&."
)

OLLAMA_MODEL = "mistral"

def generate_command(user_request: str) -> str:
    """Call ollama with a JSON prompt; return the command string."""
    prompt = {
        "role": "user",
        "content": f"{SYSTEM_PROMPT}\n\nUser: {user_request}"
    }
    completed = subprocess.run(
        ["ollama", "run", OLLAMA_MODEL, json.dumps(prompt)],
        capture_output=True, text=True, check=True,
    )
    return completed.stdout.strip()
