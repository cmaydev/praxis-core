"""Command-line entrypoint for PRAXIS-1 (v0.1.0)."""
from __future__ import annotations

import click
from praxis.llm.mistral_local import generate_command
from praxis.utils.shell import run_command

@click.command()
@click.option("--debug", is_flag=True, help="Enable debug output.")
def main(debug: bool):
    click.echo("PRAXIS-1 CLI assistant • type 'exit' to quit.")
    while True:
        user_in = input(">>> ")
        if user_in.strip().lower() in {"exit", "quit"}:
            break

        cmd = generate_command(user_in)
        if debug:
            click.echo(f"[LLM] Proposed: {cmd}")

        result = run_command(cmd)
        if result is None:
            click.secho("Blocked for safety.  (Not in whitelist.)", fg="red")
        else:
            click.secho(result, fg="green")

if __name__ == "__main__":
    main()
