"""Stub for GUI control via PyAutoGUI."""
