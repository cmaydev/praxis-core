# PRAXIS-CORE

Local autonomous assistant skeleton.
